import pytest
from pathlib import Path
from core.config import settings
from memory.database import MemoryDB
from security.manager import SecurityManager

def test_config_loading():
    assert settings.APP_NAME == "QUANT"
    assert isinstance(settings.BASE_DIR, Path)

def test_security_manager():
    sec = SecurityManager()
    # Should not raise error even if keys are missing
    key = sec.get_key("NON_EXISTENT_KEY", default="test")
    assert key == "test"

def test_memory_db(tmp_path):
    db = MemoryDB(tmp_path)
    db.add_message("user", "Hello Quant")
    history = db.get_history(limit=1)
    assert len(history) == 1
    assert history[0]["role"] == "user"
    assert history[0]["content"] == "Hello Quant"

def test_preferences(tmp_path):
    db = MemoryDB(tmp_path)
    db.set_preference("theme", "dark")
    assert db.get_preference("theme") == "dark"
