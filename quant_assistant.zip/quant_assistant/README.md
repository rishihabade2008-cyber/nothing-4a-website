# QUANT: AI Assistant

## Overview

QUANT is a production-ready, cross-platform AI assistant inspired by JARVIS from Iron Man. It features a modern, futuristic PySide6 user interface, a modular Python architecture, natural voice conversations, and integrates advanced AI capabilities, including IBM Quantum computing.

## Features

- **Natural Language Understanding & Voice**: Understands natural language commands and responds with a natural voice, featuring wake word detection ("Hey Quant"), interruptible speech, and streaming responses.
- **Modular Architecture**: Designed with a clean, scalable, and maintainable codebase, organized into distinct modules for core functionalities, assistant logic, speech, TTS, vision, automation, memory, plugins, quantum computing, settings, UI, system control, security, and logging.
- **Hybrid Memory System**: Utilizes SQLite for persistent conversation history and user preferences, and ChromaDB for semantic vector memory, enabling long-term recall and contextual understanding.
- **Advanced AI Integration**: Integrates with leading LLMs like Claude (primary), OpenAI, and Gemini for intelligent responses and command processing.
- **System Control & Automation**: Capable of controlling the computer (opening/closing applications, managing windows, setting volume, taking screenshots), automating workflows, and managing files (create, delete, move, search).
- **Web & Vision Capabilities**: Features browser automation (search, download, form filling, login) and vision processing (camera support, screen capture, OCR, object detection).
- **Document AI**: Reads and processes various document types (PDF, DOCX, TXT, Markdown, CSV) for summarization, question answering, and table extraction.
- **IBM Quantum Integration**: A dedicated module for authenticating with IBM Cloud, listing quantum backends, and executing quantum circuits (Bell State, GHZ, Random Number Generator, Deutsch-Jozsa) on simulators or real IBM Quantum hardware.
- **Dynamic Plugin System**: Allows for easy extension of QUANT's capabilities through a dynamic plugin architecture, supporting a future plugin marketplace.
- **Futuristic PySide6 UI**: A visually stunning, responsive user interface built with PySide6, featuring glassmorphism effects, animated waveforms, particle backgrounds, and holographic panels.
- **Robust Security**: All sensitive credentials are loaded from environment variables, ensuring no hardcoded secrets.
- **Comprehensive Logging & Error Handling**: Detailed logging with `loguru` and graceful error handling for production stability.
- **Unit & Integration Testing**: Thorough testing to ensure reliability and correctness of all modules.

## Tech Stack

- **Language**: Python 3.12+
- **Frontend**: PySide6 (Qt), Modern animations, Dark futuristic glassmorphism UI
- **Backend**: Async Python, Modular architecture
- **Database**: SQLite (for history), ChromaDB (for vector memory)
- **AI**: Claude API (primary), OpenAI (optional), Gemini (optional)
- **Speech Recognition**: OpenAI Whisper
- **Text To Speech**: ElevenLabs (or local fallback)
- **Automation**: Playwright, PyAutoGUI
- **Vision**: OpenCV, PyTesseract (OCR)
- **Quantum**: Qiskit, qiskit-ibm-runtime
- **Configuration**: Python-dotenv, Pydantic
- **Logging**: Loguru
- **Testing**: Pytest

## Installation Guide

### Prerequisites

- Python 3.12+
- Git
- `portaudio` (for `sounddevice` and `pyaudio`)
  - **Ubuntu/Debian**: `sudo apt-get update && sudo apt-get install portaudio19-dev`
  - **macOS**: `brew install portaudio`
  - **Windows**: Install PortAudio from [here](http://www.portaudio.com/download.html) and ensure it's in your PATH, or use a pre-compiled wheel for `pyaudio`.

### Setup Steps

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/your_username/quant.git
    cd quant
    ```

2.  **Create and activate a virtual environment:**
    ```bash
    python3 -m venv venv
    source venv/bin/activate  # On Windows: .\venv\Scripts\activate
    ```

3.  **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

4.  **Configure Environment Variables:**
    Create a `.env` file in the root directory of the project, based on `.env.example`. Fill in your API keys for Claude, OpenAI, Gemini, ElevenLabs, and IBM Cloud. Example:
    ```ini
    # .env
    CLAUDE_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    GEMINI_API_KEY=AIzaSyxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    ELEVENLABS_API_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    IBM_CLOUD_API_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    
    # Optional settings
    WHISPER_MODEL=base
    DEBUG=True
    LOG_LEVEL=INFO
    ```

5.  **Run the application:**
    ```bash
    python3 main.py
    ```

## Usage

Once QUANT is running, you can interact with it via the UI or by voice using the wake word "Hey Quant".

- **Text Commands**: Type your commands into the input field and press Enter.
- **Voice Commands**: Say "Hey Quant" followed by your command. For example, "Hey Quant, open Chrome" or "Hey Quant, run Bell State circuit."

## Architecture Diagram

![QUANT Architecture Diagram](./docs/architecture.png)

## Folder Structure

```
quant_assistant/
├── assistant/
│   ├── __init__.py
│   ├── agent.py
│   ├── llm_client.py
│   └── router.py
├── automation/
│   ├── __init__.py
│   └── file_manager.py
├── core/
│   ├── __init__.py
│   └── config.py
├── docs/
├── logging/
│   ├── __init__.py
│   └── logger.py
├── memory/
│   ├── __init__.py
│   ├── database.py
│   ├── manager.py
│   └── vector_store.py
├── plugins/
│   ├── __init__.py
│   ├── base.py
│   └── manager.py
├── quantum/
│   ├── __init__.py
│   ├── circuits.py
│   ├── manager.py
│   └── visualizer.py
├── security/
│   ├── __init__.py
│   └── manager.py
├── settings/
│   ├── __init__.py
│   └── manager.py
├── speech/
│   ├── __init__.py
│   ├── pipeline.py
│   └── recognizer.py
├── system/
│   ├── __init__.py
│   ├── controller.py
│   └── document_ai.py
├── tests/
│   └── test_core.py
├── tts/
│   ├── __init__.py
│   └── engine.py
├── ui/
│   ├── __init__.py
│   ├── main_window.py
│   ├── styles.py
│   └── widgets.py
├── vision/
│   ├── __init__.py
│   └── vision_engine.py
├── .env.example
├── main.py
└── requirements.txt
```

## Developer Guide

### Extending QUANT with Plugins

QUANT's modular design allows for easy extension through its plugin system. To create a new plugin:

1.  **Create a new directory** inside the `plugins/` folder (e.g., `plugins/my_new_plugin`).
2.  **Create an `__init__.py` file** inside your plugin directory to make it a Python package.
3.  **Create a Python file** (e.g., `my_plugin.py`) within your plugin directory.
4.  **Implement your plugin class**: Your plugin class must inherit from `plugins.base.QuantPlugin` and implement the `get_tools()` and `execute()` methods.

    ```python
    # plugins/my_new_plugin/my_plugin.py
    from plugins.base import QuantPlugin
    from typing import List, Dict, Any
    
    class MyNewPlugin(QuantPlugin):
        def __init__(self):
            super().__init__("MyNewPlugin", "0.1.0")
    
        def get_tools(self) -> List[Dict[str, Any]]:
            return [
                {
                    "name": "my_custom_action",
                    "description": "Performs a custom action.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "param1": {"type": "string"}
                        },
                        "required": ["param1"]
                    }
                }
            ]
    
        async def execute(self, tool_name: str, params: Dict[str, Any]) -> Any:
            if tool_name == "my_custom_action":
                # Implement your custom logic here
                return f"Executed custom action with param1: {params.get("param1")}"
            return None
    ```

5.  **Ensure your plugin is discoverable**: The `PluginManager` automatically discovers plugins in the `plugins/` directory. Just make sure your `__init__.py` file is present.

### Adding New AI Commands

To add new commands that QUANT can understand and execute, you'll primarily interact with the `assistant/router.py` and potentially create new modules in `system/`, `automation/`, etc.

1.  **Define the tool in `assistant/router.py`**: Add a new dictionary to the `self.tools` list in `CommandRouter._register_default_tools()`. This dictionary should describe the tool's `name`, `description`, and `parameters` using a JSON Schema format.

    ```python
    # Example for a new tool
    {
        "name": "translate_text",
        "description": "Translates text from one language to another.",
        "parameters": {
            "type": "object",
            "properties": {
                "text": {"type": "string"},
                "target_language": {"type": "string"}
            },
            "required": ["text", "target_language"]
        }
    }
    ```

2.  **Implement the tool's logic**: Create a new function or method in an appropriate module (e.g., `system/language_tools.py` or extend an existing one). This function will perform the actual work of the command.

3.  **Integrate with `QuantAgent`**: In `assistant/agent.py`, extend the `handle_tool_call` method to recognize your new `tool_name` and call the corresponding logic you implemented in step 2.

### UI Customization

- **Styling**: Modify `ui/styles.py` to change the look and feel of the application using QSS (Qt Style Sheets).
- **Widgets**: Extend or create new widgets in `ui/widgets.py` for custom UI elements like the `ParticleBackground` or `WaveformWidget`.
- **Layout**: Adjust `ui/main_window.py` to rearrange the layout or add new panels and components to the main window.

## Testing

To run the unit tests, navigate to the project root and execute:

```bash
pytest tests/
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.

---

**Author**: Manus AI
**Date**: July 31, 2026
