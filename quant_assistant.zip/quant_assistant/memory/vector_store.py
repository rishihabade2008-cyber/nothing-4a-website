import chromadb
from chromadb.config import Settings as ChromaSettings
from pathlib import Path
from typing import List, Dict, Any, Optional
from logging.logger import quant_logger

class VectorMemory:
    """
    Handles semantic search and long-term memory using ChromaDB.
    """
    def __init__(self, persist_directory: Path):
        self.persist_directory = persist_directory / "vector_db"
        self.client = chromadb.PersistentClient(path=str(self.persist_directory))
        self.collection = self.client.get_or_create_collection(name="quant_memory")

    def add_memory(self, text: str, metadata: Dict[str, Any], memory_id: str):
        """Add a piece of information to vector memory."""
        try:
            self.collection.add(
                documents=[text],
                metadatas=[metadata],
                ids=[memory_id]
            )
            quant_logger.info(f"Added to vector memory: {memory_id}")
        except Exception as e:
            quant_logger.error(f"Vector memory error: {e}")

    def query_memory(self, query_text: str, n_results: int = 5) -> List[Dict[str, Any]]:
        """Search for relevant memories based on semantic similarity."""
        try:
            results = self.collection.query(
                query_texts=[query_text],
                n_results=n_results
            )
            return results
        except Exception as e:
            quant_logger.error(f"Vector query error: {e}")
            return {"documents": [], "metadatas": [], "ids": []}

    def delete_memory(self, memory_id: str):
        try:
            self.collection.delete(ids=[memory_id])
        except Exception as e:
            quant_logger.error(f"Vector deletion error: {e}")
