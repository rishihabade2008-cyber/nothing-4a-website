from pathlib import Path
from typing import List, Dict, Any, Optional
from memory.database import MemoryDB
from memory.vector_store import VectorMemory
from core.config import settings

class MemoryManager:
    """
    Unified interface for QUANT's memory systems.
    Combines short-term history (SQLite) and long-term semantic memory (ChromaDB).
    """
    def __init__(self):
        self.db = MemoryDB(settings.MEMORY_PATH)
        self.vector = VectorMemory(settings.MEMORY_PATH)

    def remember_interaction(self, role: str, content: str, metadata: Optional[Dict[str, Any]] = None):
        """Store interaction in both history and vector memory if significant."""
        # Store in history
        self.db.add_message(role, content, str(metadata) if metadata else "")
        
        # Store in vector memory for long-term recall (only user/assistant messages)
        import uuid
        memory_id = str(uuid.uuid4())
        self.vector.add_memory(
            text=content,
            metadata={"role": role, **(metadata or {})},
            memory_id=memory_id
        )

    def search_memories(self, query: str, limit: int = 5) -> List[str]:
        """Search across all memory for relevant context."""
        results = self.vector.query_memory(query, n_results=limit)
        if results and "documents" in results and results["documents"]:
            return results["documents"][0]
        return []

    def get_recent_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        return self.db.get_history(limit=limit)

    def save_preference(self, key: str, value: Any):
        self.db.set_preference(key, str(value))

    def get_preference(self, key: str, default: Any = None) -> Any:
        return self.db.get_preference(key, default)
