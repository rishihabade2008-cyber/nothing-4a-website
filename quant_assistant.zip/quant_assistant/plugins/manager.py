import importlib
import os
import sys
from pathlib import Path
from typing import List, Dict, Any
from plugins.base import QuantPlugin
from logging.logger import quant_logger
from core.config import settings

class PluginManager:
    """
    Handles discovery and loading of plugins from the plugins directory.
    """
    def __init__(self):
        self.plugins: Dict[str, QuantPlugin] = {}
        self.plugin_dir = settings.PLUGINS_PATH
        self.plugin_dir.mkdir(exist_ok=True)
        # Add plugin dir to sys.path for dynamic imports
        sys.path.append(str(self.plugin_dir))

    def load_plugins(self):
        """Discover and load all plugins in the plugins folder."""
        for item in self.plugin_dir.iterdir():
            if item.is_dir() and (item / "__init__.py").exists():
                try:
                    module = importlib.import_module(item.name)
                    # Look for a class that inherits from QuantPlugin
                    for attr_name in dir(module):
                        attr = getattr(module, attr_name)
                        if (isinstance(attr, type) and 
                            issubclass(attr, QuantPlugin) and 
                            attr is not QuantPlugin):
                            plugin_instance = attr()
                            self.plugins[plugin_instance.name] = plugin_instance
                            quant_logger.info(f"Loaded plugin: {plugin_instance.name} v{plugin_instance.version}")
                except Exception as e:
                    quant_logger.error(f"Failed to load plugin {item.name}: {e}")

    def get_all_tools(self) -> List[Dict[str, Any]]:
        """Collect all tool definitions from enabled plugins."""
        all_tools = []
        for plugin in self.plugins.values():
            if plugin.enabled:
                all_tools.extend(plugin.get_tools())
        return all_tools

    async def execute_plugin_tool(self, tool_name: str, params: Dict[str, Any]) -> Any:
        """Find the plugin that provides the tool and execute it."""
        for plugin in self.plugins.values():
            if plugin.enabled:
                tools = plugin.get_tools()
                if any(t['name'] == tool_name for t in tools):
                    return await plugin.execute(tool_name, params)
        return None
