from abc import ABC, abstractmethod
from typing import Dict, Any, List

class QuantPlugin(ABC):
    """
    Abstract base class for all QUANT plugins.
    Plugins can extend the assistant's capabilities.
    """
    def __init__(self, name: str, version: str):
        self.name = name
        self.version = version
        self.enabled = True

    @abstractmethod
    def get_tools(self) -> List[Dict[str, Any]]:
        """Return a list of tool definitions provided by this plugin."""
        pass

    @abstractmethod
    async def execute(self, tool_name: str, params: Dict[str, Any]) -> Any:
        """Execute a specific tool provided by this plugin."""
        pass

    def on_enable(self):
        """Called when the plugin is enabled."""
        self.enabled = True

    def on_disable(self):
        """Called when the plugin is disabled."""
        self.enabled = False
