import sys
import asyncio
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QThread, Signal, Slot
from ui.main_window import MainWindow
from assistant.agent import QuantAgent
from speech.pipeline import VoicePipeline
from logging.logger import quant_logger
from core.config import settings

class AgentThread(QThread):
    """
    Runs the AI agent in a separate thread to keep the UI responsive.
    """
    response_ready = Signal(str)

    def __init__(self, agent: QuantAgent):
        super().__init__()
        self.agent = agent
        self.loop = asyncio.new_event_loop()

    def run(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def process_command(self, text: str):
        asyncio.run_coroutine_threadsafe(self._async_process(text), self.loop)

    async def _async_process(self, text: str):
        response = await self.agent.process_input(text)
        self.response_ready.emit(response)

class QuantApp:
    def __init__(self):
        self.qt_app = QApplication(sys.argv)
        self.window = MainWindow()
        self.agent = QuantAgent()
        
        # Setup Threads
        self.agent_thread = AgentThread(self.agent)
        self.agent_thread.start()
        
        # Connect UI signals
        self.window.input_field.returnPressed.connect(self.handle_input)
        self.agent_thread.response_ready.connect(self.handle_response)
        
        # Voice Pipeline
        self.voice = VoicePipeline(on_command=self.handle_input)
        self.voice.start()
        
        quant_logger.info("QUANT initialized and ready.")

    def handle_input(self, text: str = None):
        if text is None:
            text = self.window.input_field.text()
        
        if not text: return
        
        self.window.append_message("USER", text)
        self.window.input_field.clear()
        self.agent_thread.process_command(text)
        self.window.waveform.is_active = True

    @Slot(str)
    def handle_response(self, response: str):
        self.window.append_message("QUANT", response)
        self.window.waveform.is_active = False
        self.voice.respond(response)

    def run(self):
        self.window.show()
        sys.exit(self.qt_app.exec())

if __name__ == "__main__":
    app = QuantApp()
    app.run()
