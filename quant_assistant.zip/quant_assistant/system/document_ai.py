import PyPDF2
import docx
from typing import Optional
from logging.logger import quant_logger

class DocumentAI:
    """
    Handles extraction and processing of document contents.
    """
    def read_pdf(self, path: str) -> str:
        try:
            text = ""
            with open(path, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                for page in reader.pages:
                    text += page.extract_text()
            return text
        except Exception as e:
            quant_logger.error(f"PDF read error: {e}")
            return ""

    def read_docx(self, path: str) -> str:
        try:
            doc = docx.Document(path)
            return "\n".join([p.text for p in doc.paragraphs])
        except Exception as e:
            quant_logger.error(f"DOCX read error: {e}")
            return ""

    def summarize(self, text: str) -> str:
        """This would normally call the LLM, but we provide the text extraction here."""
        # The QuantAgent will handle the actual summarization using extracted text.
        return text
