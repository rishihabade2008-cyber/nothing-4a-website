import os
import subprocess
import platform
import pyautogui
import psutil
from typing import List, Dict, Any
from logging.logger import quant_logger

class SystemController:
    """
    Handles OS-level commands like opening apps, controlling volume, and screenshots.
    Cross-platform support (Windows, macOS, Linux).
    """
    def __init__(self):
        self.os_type = platform.system()

    def open_application(self, app_name: str):
        try:
            if self.os_type == "Windows":
                os.startfile(app_name)
            elif self.os_type == "Darwin":  # macOS
                subprocess.run(["open", "-a", app_name])
            else:  # Linux
                subprocess.run(["xdg-open", app_name])
            quant_logger.info(f"Opened application: {app_name}")
        except Exception as e:
            quant_logger.error(f"Failed to open {app_name}: {e}")

    def set_volume(self, level: int):
        """Sets system volume (0-100)."""
        try:
            if self.os_type == "Windows":
                # Implementation using pycaw or similar would go here
                pass
            elif self.os_type == "Darwin":
                subprocess.run(["osascript", "-e", f"set volume output volume {level}"])
            quant_logger.info(f"Volume set to {level}")
        except Exception as e:
            quant_logger.error(f"Failed to set volume: {e}")

    def take_screenshot(self, filename: str = "screenshot.png"):
        try:
            screenshot = pyautogui.screenshot()
            screenshot.save(filename)
            quant_logger.info(f"Screenshot saved to {filename}")
            return filename
        except Exception as e:
            quant_logger.error(f"Failed to take screenshot: {e}")
            return None

    def get_system_stats(self) -> Dict[str, Any]:
        return {
            "cpu_usage": psutil.cpu_percent(),
            "memory_usage": psutil.virtual_memory().percent,
            "disk_usage": psutil.disk_usage('/').percent
        }
