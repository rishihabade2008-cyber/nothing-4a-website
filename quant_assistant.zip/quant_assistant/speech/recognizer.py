import whisper
import numpy as np
import sounddevice as sd
import queue
import sys
import time
from typing import Optional, Callable
from logging.logger import quant_logger
from core.config import settings

class SpeechRecognizer:
    """
    Handles voice recording and speech-to-text using OpenAI Whisper.
    Includes basic Voice Activity Detection (VAD).
    """
    def __init__(self, model_name: str = "base"):
        quant_logger.info(f"Loading Whisper model: {model_name}...")
        self.model = whisper.load_model(model_name)
        self.audio_queue = queue.Queue()
        self.sample_rate = 16000
        self.is_listening = False
        self.wake_word = "hey quant"

    def _audio_callback(self, indata, frames, time, status):
        """Callback for sounddevice to capture audio chunks."""
        if status:
            quant_logger.warning(f"Audio status: {status}")
        self.audio_queue.put(indata.copy())

    def listen_and_transcribe(self, callback: Callable[[str], None]):
        """
        Continuously listens to the microphone and transcribes speech.
        Triggers callback when a sentence is detected.
        """
        self.is_listening = True
        quant_logger.info("Speech recognition started.")
        
        with sd.InputStream(samplerate=self.sample_rate, channels=1, callback=self._audio_callback):
            audio_data = []
            while self.is_listening:
                try:
                    chunk = self.audio_queue.get(timeout=1.0)
                    audio_data.append(chunk)
                    
                    # Simple VAD: Check if we have enough audio and if it's silent
                    if len(audio_data) > 20:  # Approx 2-3 seconds
                        full_audio = np.concatenate(audio_data).flatten().astype(np.float32)
                        
                        # Check energy level
                        if np.abs(full_audio).mean() > 0.01:
                            # Transcribe
                            result = self.model.transcribe(full_audio, fp16=False)
                            text = result['text'].strip().lower()
                            
                            if text:
                                quant_logger.info(f"Transcribed: {text}")
                                callback(text)
                                audio_data = []  # Clear after transcription
                        else:
                            # Too quiet, discard oldest chunk to keep window moving
                            audio_data.pop(0)
                except queue.Empty:
                    continue
                except Exception as e:
                    quant_logger.error(f"STT Error: {e}")
                    break

    def stop(self):
        self.is_listening = False
        quant_logger.info("Speech recognition stopped.")
