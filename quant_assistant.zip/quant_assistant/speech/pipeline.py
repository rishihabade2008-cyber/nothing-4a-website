import threading
from typing import Callable, Optional
from speech.recognizer import SpeechRecognizer
from tts.engine import TTSEngine
from logging.logger import quant_logger

class VoicePipeline:
    """
    Coordinates STT and TTS for natural voice conversations.
    Handles wake word detection and interruption.
    """
    def __init__(self, on_command: Callable[[str], None]):
        self.recognizer = SpeechRecognizer()
        self.tts = TTSEngine()
        self.on_command = on_command
        self.is_active = False
        self.wake_word = "hey quant"
        self._thread: Optional[threading.Thread] = None

    def start(self):
        """Start the voice pipeline in a background thread."""
        self.is_active = True
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        quant_logger.info("Voice pipeline active.")

    def _run(self):
        self.recognizer.listen_and_transcribe(self._handle_transcription)

    def _handle_transcription(self, text: str):
        """Processes transcribed text, looking for wake word or active session."""
        if self.wake_word in text:
            # Extract command after wake word
            command = text.split(self.wake_word)[-1].strip()
            if command:
                quant_logger.info(f"Wake word detected with command: {command}")
                self.on_command(command)
            else:
                quant_logger.info("Wake word detected. Awaiting command...")
                self.tts.speak("I am listening.")
        else:
            # If we are in an active conversation mode, we might process all text
            # For now, just log and wait for wake word
            quant_logger.debug(f"Ignored (no wake word): {text}")

    def respond(self, text: str):
        """Speak a response to the user."""
        self.tts.speak(text)

    def stop(self):
        self.is_active = False
        self.recognizer.stop()
        self.tts.stop()
        quant_logger.info("Voice pipeline stopped.")
