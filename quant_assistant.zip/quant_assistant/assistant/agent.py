import asyncio
from typing import Optional, Dict, Any
from assistant.llm_client import LLMClient
from assistant.router import CommandRouter
from memory.manager import MemoryManager
from logging.logger import quant_logger

class QuantAgent:
    """
    The central intelligence of QUANT.
    Coordinates memory, LLM, and tool execution.
    """
    def __init__(self):
        self.llm = LLMClient()
        self.router = CommandRouter()
        self.memory = MemoryManager()
        self.system_prompt = self.router.get_system_prompt()

    async def process_input(self, user_input: str) -> str:
        """
        Processes user input (text or transcribed voice) and returns a response.
        """
        quant_logger.info(f"Processing input: {user_input}")
        
        # 1. Retrieve context from memory
        context = self.memory.search_memories(user_input)
        history = self.memory.get_recent_history(limit=5)
        
        # 2. Construct messages
        messages = []
        for h in history:
            messages.append({"role": h["role"], "content": h["content"]})
        
        # Add context as a system note if relevant
        if context:
            context_note = f"Relevant context from memory: {' '.join(context)}"
            messages.append({"role": "user", "content": f"[System Context: {context_note}]\n{user_input}"})
        else:
            messages.append({"role": "user", "content": user_input})

        # 3. Get LLM response
        response = await self.llm.chat(messages, self.system_prompt)
        
        # 4. Remember the interaction
        self.memory.remember_interaction("user", user_input)
        self.memory.remember_interaction("assistant", response)
        
        return response

    def handle_tool_call(self, tool_name: str, params: Dict[str, Any]):
        """Executes a tool call requested by the LLM."""
        quant_logger.info(f"Executing tool: {tool_name} with {params}")
        # Implementation for specific tools will be in Phase 5 & 6
        return f"Executing {tool_name}..."
