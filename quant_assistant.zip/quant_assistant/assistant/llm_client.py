import anthropic
import openai
from typing import List, Dict, Any, Optional
from logging.logger import quant_logger
from core.config import settings, security

class LLMClient:
    """
    Unified client for interacting with AI models (Claude, OpenAI).
    """
    def __init__(self, provider: str = "anthropic"):
        self.provider = provider
        self.claude = anthropic.Anthropic(api_key=security.claude_key) if security.claude_key else None
        self.openai = openai.OpenAI(api_key=security.openai_key) if security.openai_key else None

    async def chat(self, messages: List[Dict[str, str]], system_prompt: str = "") -> str:
        """Sends a chat request to the configured provider."""
        if self.provider == "anthropic" and self.claude:
            return await self._call_claude(messages, system_prompt)
        elif self.provider == "openai" and self.openai:
            return await self._call_openai(messages, system_prompt)
        else:
            error_msg = f"LLM Provider {self.provider} not configured or API key missing."
            quant_logger.error(error_msg)
            return "I'm sorry, my AI core is not properly configured. Please check your API keys."

    async def _call_claude(self, messages: List[Dict[str, str]], system_prompt: str) -> str:
        try:
            # Convert OpenAI-style messages to Anthropic style
            formatted_messages = []
            for m in messages:
                if m["role"] != "system":
                    formatted_messages.append({"role": m["role"], "content": m["content"]})
            
            response = self.claude.messages.create(
                model=settings.DEFAULT_LLM,
                max_tokens=4096,
                system=system_prompt,
                messages=formatted_messages
            )
            return response.content[0].text
        except Exception as e:
            quant_logger.error(f"Claude API Error: {e}")
            return f"Error communicating with Claude: {str(e)}"

    async def _call_openai(self, messages: List[Dict[str, str]], system_prompt: str) -> str:
        try:
            full_messages = [{"role": "system", "content": system_prompt}] + messages
            response = self.openai.chat.completions.create(
                model="gpt-4-turbo-preview",
                messages=full_messages
            )
            return response.choices[0].message.content
        except Exception as e:
            quant_logger.error(f"OpenAI API Error: {e}")
            return f"Error communicating with OpenAI: {str(e)}"
