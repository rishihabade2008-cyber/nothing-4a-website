from typing import List, Dict, Any, Callable
from logging.logger import quant_logger

class CommandRouter:
    """
    Routes user intents to specific functional modules.
    Defines the tools available to the AI assistant.
    """
    def __init__(self):
        self.tools = []
        self._register_default_tools()

    def _register_default_tools(self):
        self.tools = [
            {
                "name": "run_quantum_circuit",
                "description": "Execute a quantum circuit on IBM Quantum hardware or simulator.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "circuit_type": {"type": "string", "enum": ["bell_state", "ghz", "random_number", "dj"]},
                        "backend": {"type": "string", "default": "simulator"}
                    },
                    "required": ["circuit_type"]
                }
            },
            {
                "name": "system_control",
                "description": "Control system applications, volume, or brightness.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "action": {"type": "string", "enum": ["open_app", "close_app", "set_volume", "screenshot"]},
                        "target": {"type": "string"}
                    },
                    "required": ["action"]
                }
            },
            {
                "name": "file_management",
                "description": "Manage files: create, delete, move, or search.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "action": {"type": "string", "enum": ["create", "delete", "move", "search"]},
                        "path": {"type": "string"},
                        "destination": {"type": "string"}
                    },
                    "required": ["action", "path"]
                }
            },
            {
                "name": "web_search",
                "description": "Search the web for information.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"}
                    },
                    "required": ["query"]
                }
            }
        ]

    def get_system_prompt(self) -> str:
        return f"""
        You are QUANT, a sophisticated AI assistant inspired by JARVIS.
        Your goal is to assist the user with natural language, system control, and quantum computing.
        
        Available Tools:
        {self.tools}
        
        If a user request matches a tool, you should respond by suggesting the tool call.
        Always maintain a professional, helpful, and slightly futuristic persona.
        """
