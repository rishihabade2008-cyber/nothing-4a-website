import sys
from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                             QLabel, QTextEdit, QLineEdit, QPushButton, QFrame, QStackedWidget)
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QIcon, QFont
from ui.styles import FUTURISTIC_STYLE
from ui.widgets import ParticleBackground, WaveformWidget
from logging.logger import quant_logger

class MainWindow(QMainWindow):
    """
    Main QUANT Dashboard.
    Holographic glassmorphism interface.
    """
    def __init__(self):
        super().__init__()
        self.setWindowTitle("QUANT - AI Assistant")
        self.resize(1000, 700)
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        
        self.setup_ui()
        self.setStyleSheet(FUTURISTIC_STYLE)

    def setup_ui(self):
        # Central Widget with Glass Effect
        self.central_widget = QWidget()
        self.central_widget.setObjectName("CentralWidget")
        self.setCentralWidget(self.central_widget)
        
        self.main_layout = QVBoxLayout(self.central_widget)
        
        # Particle Background (Z-index handled by being the first added)
        self.bg = ParticleBackground(self.central_widget)
        self.bg.setGeometry(0, 0, 1000, 700)
        self.bg.lower()

        # Header
        header = QHBoxLayout()
        title = QLabel("QUANT // OS")
        title.setObjectName("TitleLabel")
        header.addWidget(title)
        header.addStretch()
        
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(30, 30)
        close_btn.clicked.connect(self.close)
        header.addWidget(close_btn)
        
        self.main_layout.addLayout(header)

        # Main Content Area
        content = QHBoxLayout()
        
        # Left Sidebar (System Stats)
        sidebar = QFrame()
        sidebar.setObjectName("GlassPanel")
        sidebar.setFixedWidth(200)
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.addWidget(QLabel("SYSTEM STATUS"))
        sidebar_layout.addWidget(QLabel("CPU: 12%"))
        sidebar_layout.addWidget(QLabel("RAM: 4.2GB"))
        sidebar_layout.addWidget(QLabel("QUANTUM: ONLINE"))
        sidebar_layout.addStretch()
        content.addWidget(sidebar)

        # Center Area (Chat and Waveform)
        center = QVBoxLayout()
        
        self.chat_history = QTextEdit()
        self.chat_history.setReadOnly(True)
        self.chat_history.setObjectName("GlassPanel")
        center.addWidget(self.chat_history)
        
        self.waveform = WaveformWidget()
        center.addWidget(self.waveform)
        
        input_area = QHBoxLayout()
        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Enter command or 'Hey Quant'...")
        input_area.addWidget(self.input_field)
        
        send_btn = QPushButton("SEND")
        input_area.addWidget(send_btn)
        center.addLayout(input_area)
        
        content.addLayout(center, stretch=1)
        
        self.main_layout.addLayout(content)

    def append_message(self, role: str, message: str):
        color = "#00ffff" if role == "QUANT" else "#ffffff"
        self.chat_history.append(f"<b style='color:{color}'>{role}:</b> {message}")

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.dragPos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton:
            self.move(self.pos() + event.globalPosition().toPoint() - self.dragPos)
            self.dragPos = event.globalPosition().toPoint()
            event.accept()
