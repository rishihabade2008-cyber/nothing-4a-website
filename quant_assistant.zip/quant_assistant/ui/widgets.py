import random
from PySide6.QtWidgets import QWidget, QPushButton, QVBoxLayout, QHBoxLayout
from PySide6.QtCore import Qt, QTimer, QPointF, QRectF
from PySide6.QtGui import QPainter, QColor, QPen, QBrush, QLinearGradient

class Particle:
    def __init__(self, width, height):
        self.x = random.randint(0, width)
        self.y = random.randint(0, height)
        self.vx = random.uniform(-0.5, 0.5)
        self.vy = random.uniform(-0.5, 0.5)
        self.size = random.randint(1, 3)

    def update(self, width, height):
        self.x += self.vx
        self.y += self.vy
        if self.x < 0 or self.x > width: self.vx *= -1
        if self.y < 0 or self.y > height: self.vy *= -1

class ParticleBackground(QWidget):
    """
    Animated particle background for a futuristic feel.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.particles = [Particle(800, 600) for _ in range(50)]
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update)
        self.timer.start(30)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(Qt.NoPen)
        
        for p in self.particles:
            p.update(self.width(), self.height())
            color = QColor(0, 255, 255, 100)
            painter.setBrush(QBrush(color))
            painter.drawEllipse(QPointF(p.x, p.y), p.size, p.size)

class WaveformWidget(QWidget):
    """
    Animated voice waveform visualization.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(100)
        self.amplitudes = [0] * 50
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._animate)
        self.timer.start(50)
        self.is_active = False

    def _animate(self):
        if self.is_active:
            self.amplitudes.pop(0)
            self.amplitudes.append(random.randint(10, 80))
        else:
            self.amplitudes.pop(0)
            self.amplitudes.append(2)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        w = self.width()
        h = self.height()
        bar_w = w / len(self.amplitudes)
        
        for i, amp in enumerate(self.amplitudes):
            color = QColor(0, 255, 255, 200)
            painter.setPen(QPen(color, 2))
            x = i * bar_w
            painter.drawLine(x, h/2 - amp/2, x, h/2 + amp/2)
