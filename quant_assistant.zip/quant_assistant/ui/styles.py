FUTURISTIC_STYLE = """
QMainWindow {
    background-color: transparent;
}

QWidget#CentralWidget {
    background-color: rgba(10, 20, 30, 180);
    border: 1px solid rgba(0, 255, 255, 50);
    border-radius: 20px;
}

QFrame#GlassPanel {
    background-color: rgba(255, 255, 255, 10);
    border: 1px solid rgba(255, 255, 255, 20);
    border-radius: 15px;
}

QLabel {
    color: #00ffff;
    font-family: 'Segoe UI', sans-serif;
    font-size: 14px;
}

QLabel#TitleLabel {
    font-size: 24px;
    font-weight: bold;
    color: #ffffff;
    letter-spacing: 2px;
}

QPushButton {
    background-color: rgba(0, 255, 255, 20);
    color: #00ffff;
    border: 1px solid #00ffff;
    border-radius: 5px;
    padding: 8px 15px;
    font-weight: bold;
}

QPushButton:hover {
    background-color: rgba(0, 255, 255, 40);
}

QPushButton:pressed {
    background-color: rgba(0, 255, 255, 60);
}

QTextEdit, QLineEdit {
    background-color: rgba(0, 0, 0, 100);
    color: #ffffff;
    border: 1px solid rgba(0, 255, 255, 50);
    border-radius: 5px;
    padding: 5px;
}

QScrollBar:vertical {
    border: none;
    background: rgba(0, 0, 0, 50);
    width: 8px;
    border-radius: 4px;
}

QScrollBar::handle:vertical {
    background: rgba(0, 255, 255, 100);
    min-height: 20px;
    border-radius: 4px;
}
"""
