from pathlib import Path
from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from security.manager import SecurityManager

class Settings(BaseSettings):
    """
    Application-wide settings managed via environment variables and Pydantic.
    """
    APP_NAME: str = "QUANT"
    VERSION: str = "1.0.0"
    DEBUG: bool = False
    LOG_LEVEL: str = "INFO"
    
    # Paths
    BASE_DIR: Path = Path(__file__).parent.parent
    MEMORY_PATH: Path = BASE_DIR / "memory_db"
    PLUGINS_PATH: Path = BASE_DIR / "plugins"
    ASSETS_PATH: Path = BASE_DIR / "assets"
    
    # AI Models
    WHISPER_MODEL: str = "base"
    DEFAULT_LLM: str = "claude-3-opus-20240229"
    
    # Quantum Config
    IBM_QUANTUM_HUB: str = "ibm-q"
    IBM_QUANTUM_GROUP: str = "open"
    IBM_QUANTUM_PROJECT: str = "main"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

# Global settings instance
settings = Settings()
security = SecurityManager()
