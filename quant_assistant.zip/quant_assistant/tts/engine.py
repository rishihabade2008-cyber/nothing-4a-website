import os
import requests
from typing import Optional
from logging.logger import quant_logger
from core.config import settings, security
import sounddevice as sd
import soundfile as sf
import io

class TTSEngine:
    """
    Handles text-to-speech using ElevenLabs API.
    Provides natural-sounding voice responses.
    """
    def __init__(self):
        self.api_key = security.elevenlabs_key
        self.voice_id = "pNInz6obpgmqtVJKsMQC"  # Default 'Adam' voice, JARVIS-like
        self.api_url = f"https://api.elevenlabs.io/v1/text-to-speech/{self.voice_id}"

    def speak(self, text: str, wait: bool = True):
        """
        Converts text to speech and plays it.
        """
        if not self.api_key:
            quant_logger.warning("ElevenLabs API key not set. Using local fallback (gTTS or similar could be here).")
            print(f"QUANT: {text}")
            return

        headers = {
            "Accept": "audio/mpeg",
            "Content-Type": "application/json",
            "xi-api-key": self.api_key
        }

        data = {
            "text": text,
            "model_id": "eleven_monolingual_v1",
            "voice_settings": {
                "stability": 0.5,
                "similarity_boost": 0.75
            }
        }

        try:
            quant_logger.info(f"Generating speech for: {text[:50]}...")
            response = requests.post(self.api_url, json=data, headers=headers)
            
            if response.status_code == 200:
                audio_data = io.BytesIO(response.content)
                data, fs = sf.read(audio_data)
                sd.play(data, fs)
                if wait:
                    sd.wait()
            else:
                quant_logger.error(f"ElevenLabs API error: {response.status_code} - {response.text}")
        except Exception as e:
            quant_logger.error(f"TTS Error: {e}")

    def stop(self):
        """Stop any ongoing speech."""
        sd.stop()
