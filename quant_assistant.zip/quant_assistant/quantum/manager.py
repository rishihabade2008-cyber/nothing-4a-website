from qiskit_ibm_runtime import QiskitRuntimeService, Sampler, Session
from qiskit import QuantumCircuit
from typing import List, Dict, Any, Optional
from logging.logger import quant_logger
from core.config import settings, security

class QuantumManager:
    """
    Handles connection to IBM Quantum and execution of circuits.
    Supports both real hardware and simulators.
    """
    def __init__(self):
        self.service = None
        self.api_key = security.ibm_quantum_key

    def authenticate(self) -> bool:
        """Authenticate with IBM Cloud/Quantum."""
        if not self.api_key:
            quant_logger.error("IBM Cloud API Key not found.")
            return False
        try:
            self.service = QiskitRuntimeService(
                channel="ibm_quantum",
                token=self.api_key,
                instance=f"{settings.IBM_QUANTUM_HUB}/{settings.IBM_QUANTUM_GROUP}/{settings.IBM_QUANTUM_PROJECT}"
            )
            quant_logger.info("Authenticated with IBM Quantum.")
            return True
        except Exception as e:
            quant_logger.error(f"IBM Quantum Auth Error: {e}")
            return False

    def list_backends(self) -> List[Dict[str, Any]]:
        """List available quantum backends and their status."""
        if not self.service:
            if not self.authenticate(): return []
        
        backends = self.service.backends()
        return [{
            "name": b.name,
            "qubits": b.num_qubits,
            "status": b.status().status_msg,
            "pending_jobs": b.status().pending_jobs
        } for b in backends]

    def run_circuit(self, circuit: QuantumCircuit, backend_name: str = "ibmq_qasm_simulator"):
        """Executes a quantum circuit on the specified backend."""
        if not self.service:
            if not self.authenticate(): return None
        
        try:
            backend = self.service.backend(backend_name)
            quant_logger.info(f"Running circuit on {backend_name}...")
            
            with Session(service=self.service, backend=backend) as session:
                sampler = Sampler(session=session)
                job = sampler.run(circuit)
                result = job.result()
                quant_logger.info(f"Quantum job {job.job_id()} completed.")
                return result
        except Exception as e:
            quant_logger.error(f"Quantum execution error: {e}")
            return None
