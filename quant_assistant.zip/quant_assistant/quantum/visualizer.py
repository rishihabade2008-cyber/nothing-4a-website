import matplotlib.pyplot as plt
from qiskit.visualization import plot_histogram
from typing import Any, Optional
from logging.logger import quant_logger
import io

class QuantumVisualizer:
    """
    Handles visualization of quantum job results.
    """
    def plot_results(self, result: Any, filename: str = "quantum_result.png"):
        """Plots the histogram of quantum measurement results."""
        try:
            # result is a SamplerResult in qiskit-ibm-runtime
            # We need to extract quasi-probabilities
            quasi_dists = result.quasi_dists[0]
            
            # Plot
            fig = plot_histogram(quasi_dists)
            fig.savefig(filename)
            plt.close(fig)
            
            quant_logger.info(f"Quantum result plot saved to {filename}")
            return filename
        except Exception as e:
            quant_logger.error(f"Visualization error: {e}")
            return None

    def get_result_summary(self, result: Any) -> str:
        """Returns a text summary of the quantum results."""
        try:
            quasi_dists = result.quasi_dists[0]
            # Convert binary keys
            summary = "Measurement Probabilities:\n"
            for outcome, prob in quasi_dists.items():
                binary = format(outcome, 'b').zfill(2) # simplified
                summary += f"State |{binary}>: {prob:.4f}\n"
            return summary
        except Exception as e:
            return f"Error summarizing results: {e}"
