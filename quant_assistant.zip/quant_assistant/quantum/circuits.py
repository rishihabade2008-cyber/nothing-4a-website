from qiskit import QuantumCircuit
import numpy as np

class QuantumCircuits:
    """
    Collection of pre-defined quantum circuits for demonstration and utility.
    """
    @staticmethod
    def bell_state() -> QuantumCircuit:
        """Creates a Bell State (entanglement)."""
        qc = QuantumCircuit(2)
        qc.h(0)
        qc.cx(0, 1)
        qc.measure_all()
        return qc

    @staticmethod
    def ghz_state(n_qubits: int = 3) -> QuantumCircuit:
        """Creates a GHZ State (multi-qubit entanglement)."""
        qc = QuantumCircuit(n_qubits)
        qc.h(0)
        for i in range(n_qubits - 1):
            qc.cx(i, i + 1)
        qc.measure_all()
        return qc

    @staticmethod
    def random_number_generator(n_qubits: int = 4) -> QuantumCircuit:
        """Generates a quantum random number."""
        qc = QuantumCircuit(n_qubits)
        for i in range(n_qubits):
            qc.h(i)
        qc.measure_all()
        return qc

    @staticmethod
    def deutsch_jozsa(n: int = 3, oracle_type: str = "balanced") -> QuantumCircuit:
        """Implementation of the Deutsch-Jozsa algorithm."""
        qc = QuantumCircuit(n + 1, n)
        # Initialization
        for qubit in range(n):
            qc.h(qubit)
        qc.x(n)
        qc.h(n)
        
        # Oracle (simplified example)
        if oracle_type == "balanced":
            for qubit in range(n):
                qc.cx(qubit, n)
        
        # Final Hadamards
        for qubit in range(n):
            qc.h(qubit)
        
        for i in range(n):
            qc.measure(i, i)
        return qc
