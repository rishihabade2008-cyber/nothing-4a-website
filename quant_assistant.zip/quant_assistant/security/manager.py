import os
from pathlib import Path
from dotenv import load_dotenv
from typing import Optional
import logging

class SecurityManager:
    """
    Handles secure access to API keys and environment variables.
    Ensures no credentials are hardcoded.
    """
    def __init__(self, env_path: Optional[str] = None):
        if env_path:
            load_dotenv(env_path)
        else:
            # Look for .env in the root project directory
            root_dir = Path(__file__).parent.parent
            load_dotenv(root_dir / ".env")

    def get_key(self, key_name: str, default: Optional[str] = None) -> Optional[str]:
        """Retrieve an API key or configuration value from environment variables."""
        value = os.getenv(key_name, default)
        if not value and not default:
            logging.warning(f"Security Warning: {key_name} is not set in environment variables.")
        return value

    @property
    def claude_key(self) -> Optional[str]:
        return self.get_key("CLAUDE_API_KEY")

    @property
    def openai_key(self) -> Optional[str]:
        return self.get_key("OPENAI_API_KEY")

    @property
    def gemini_key(self) -> Optional[str]:
        return self.get_key("GEMINI_API_KEY")

    @property
    def ibm_quantum_key(self) -> Optional[str]:
        return self.get_key("IBM_CLOUD_API_KEY")

    @property
    def elevenlabs_key(self) -> Optional[str]:
        return self.get_key("ELEVENLABS_API_KEY")
