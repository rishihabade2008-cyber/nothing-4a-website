import os
import shutil
import glob
from pathlib import Path
from typing import List, Optional
from logging.logger import quant_logger

class FileManager:
    """
    Handles file system operations safely.
    """
    def create_file(self, path: str, content: str = ""):
        try:
            with open(path, 'w') as f:
                f.write(content)
            quant_logger.info(f"Created file: {path}")
        except Exception as e:
            quant_logger.error(f"File creation error: {e}")

    def delete_path(self, path: str):
        try:
            if os.path.isfile(path):
                os.remove(path)
            elif os.path.isdir(path):
                shutil.rmtree(path)
            quant_logger.info(f"Deleted: {path}")
        except Exception as e:
            quant_logger.error(f"Deletion error: {e}")

    def search_files(self, pattern: str, root_dir: str = ".") -> List[str]:
        try:
            search_path = os.path.join(root_dir, "**", pattern)
            results = glob.glob(search_path, recursive=True)
            return results
        except Exception as e:
            quant_logger.error(f"Search error: {e}")
            return []

    def move_file(self, src: str, dst: str):
        try:
            shutil.move(src, dst)
            quant_logger.info(f"Moved {src} to {dst}")
        except Exception as e:
            quant_logger.error(f"Move error: {e}")
