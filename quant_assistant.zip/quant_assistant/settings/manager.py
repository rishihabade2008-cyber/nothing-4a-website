import json
from pathlib import Path
from typing import Any, Dict
from logging.logger import quant_logger
from core.config import settings

class SettingsManager:
    """
    Manages user preferences and application state.
    Persists data to a JSON file.
    """
    def __init__(self):
        self.settings_file = settings.BASE_DIR / "settings.json"
        self.defaults = {
            "theme": "dark_futuristic",
            "voice_enabled": True,
            "voice_id": "pNInz6obpgmqtVJKsMQC",
            "language": "en",
            "startup_open": False,
            "hotkeys": {
                "wake": "Ctrl+Space"
            },
            "api_keys": {}
        }
        self.current_settings = self.load()

    def load(self) -> Dict[str, Any]:
        if self.settings_file.exists():
            try:
                with open(self.settings_file, 'r') as f:
                    data = json.load(f)
                    # Merge with defaults to ensure all keys exist
                    return {**self.defaults, **data}
            except Exception as e:
                quant_logger.error(f"Failed to load settings: {e}")
        return self.defaults.copy()

    def save(self):
        try:
            with open(self.settings_file, 'w') as f:
                json.dump(self.current_settings, f, indent=4)
        except Exception as e:
            quant_logger.error(f"Failed to save settings: {e}")

    def get(self, key: str, default: Any = None) -> Any:
        return self.current_settings.get(key, default)

    def set(self, key: str, value: Any):
        self.current_settings[key] = value
        self.save()
        quant_logger.info(f"Setting updated: {key} = {value}")
